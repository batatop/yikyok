import React from "react"
import { View, Text } from "react-native"

class Posts extends React.Component {
    render() {
        return(
            <View>
                <Text>Posts</Text>
            </View>
        );
    }
}

export default Posts;